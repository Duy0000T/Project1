CREATE DATABASE noteworks CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE noteworks;

CREATE TABLE users (
                       id INT AUTO_INCREMENT PRIMARY KEY,
                       username VARCHAR(50) NOT NULL UNIQUE,
                       email VARCHAR(100) NOT NULL UNIQUE,
                       password VARCHAR(255) NOT NULL,
                       full_name VARCHAR(100),
                       created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            user_id INT NOT NULL,
                            name VARCHAR(50) NOT NULL,
                            color VARCHAR(20) DEFAULT '#6c757d', -- Mã màu Hex
                            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE schedule (
                          id INT AUTO_INCREMENT PRIMARY KEY,
                          user_id INT NOT NULL,
                          title VARCHAR(255) NOT NULL,
                          type ENUM('class', 'event') NOT NULL DEFAULT 'class',
                          event_date DATE NOT NULL,
                          start_time TIME NOT NULL,
                          end_time TIME NOT NULL,
                          location VARCHAR(255) NULL,
                          description TEXT NULL,
                          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                          CONSTRAINT check_time_valid CHECK (end_time > start_time)
);

CREATE TABLE tasks (
                       id INT AUTO_INCREMENT PRIMARY KEY,
                       user_id INT NOT NULL,
                       category_id INT NULL,
                       parent_id INT NULL,

                       title VARCHAR(255) NOT NULL,
                       description TEXT,
                       status ENUM('pending', 'completed') DEFAULT 'pending',
                       due_date DATETIME NULL,
                       created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

                       FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                       FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
                       FOREIGN KEY (parent_id) REFERENCES tasks(id) ON DELETE CASCADE
);

CREATE TABLE files (
                       id INT AUTO_INCREMENT PRIMARY KEY,
                       user_id INT NOT NULL,
                       task_id INT NULL,
                       schedule_id INT NULL,
                       filename VARCHAR(255) NOT NULL,
                       filepath VARCHAR(500) NOT NULL,
                       file_type ENUM('general', 'att', 'proof') DEFAULT 'general',
                       uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                       FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                       FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE SET NULL,
                       FOREIGN KEY (schedule_id) REFERENCES schedule(id) ON DELETE SET NULL
);